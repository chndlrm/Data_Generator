# Dummy Data Generator
# 2/11/19

import sqlite3
import random

conn = sqlite3.connect("475.db")
c = conn.cursor()


def fill_dep():
    dname = ['Human Resource', 'Marketing', 'Finance', 'Maintenance']
    head = [1999, 999, 111, 4444]
    for i in range(len(dname)):
        created = str(random.randint(2000, 2019)) + "-" + str(random.randint(1, 12)) + "-" + str(random.randint(1, 28))
        c.execute("INSERT INTO Department VALUES(?,?,?)", (dname[i], created, head[i]))

def fill_emp():
    ffile = open('FirstNames.txt')
    mfile = open('MiddleNames.txt')
    lfile = open('LastNames.txt')
    stfile = open('StreetNames.txt')
    fname = list(ffile)
    mname = list(mfile)
    lname = list(lfile)
    stname = list(stfile)
    numOfEmps = 50
    empID = [x for x in range(50)]
    title = ['Developer', 'Worker', 'Supervisor', 'Manager']
    print(len(fname), len(mname), len(lname))


    for i in range(numOfEmps):
        fRan = random.randint(0, len(fname) - 1)
        mRan = random.randint(0, len(mname) - 1)
        lRan = random.randint(0, len(lname) - 1)
        print(fRan, mRan,lRan)
        address = str(random.randint(1000, 10000)) + " " + stname[i]
        created = str(random.randint(2000, 2019)) + "-" + str(random.randint(1, 12)) + "-" + str(random.randint(1, 28))
        c.execute("INSERT INTO Employee VALUES(?,?,?,?,?,?,?,?,?)",
                  (empID[i], fname[fRan], mname[mRan], lname[lRan],
                   address, random.randint(1, 4), created,
                   title[random.randint(0, 3)], random.randint(30000, 150000)))
    ffile.close()
    mfile.close()
    lfile.close()
    stfile.close()

def fill_inv():
    ran = random.randint(1, 100)
    partID = [x for x in range(ran)]
    for i in range(ran):
        quantity = random.randint(1, 1000)
        created = str(random.randint(2000, 2019)) + "-" + str(random.randint(1, 12)) + "-" + str(random.randint(1, 28))
        c.execute("INSERT INTO Inventory VALUES(?,?,?)", (partID[i], quantity, created))

    return partID


#
# def fill_maint():

def fill_part(pID):
    file = open('Pname.txt')
    plst = list(file)
    for i in range(len(pID)):
        c.execute("INSERT INTO Part VALUES(?,?)", (plst[i], pID[i]))
    file.close()



# def fill_RL():



def create_table():
    # c.execute('DROP TABLE Employees')
    # c.execute("""Create TABLE Employees (first text, last text, pay integer)""")
    conn.commit()

def data_entry():
    # c.execute("INSERT INTO Employees VALUES('john', 'python', 5)")
    # c.execute("INSERT INTO Employee VALUES(1000, 'john', 'j', 'Kim', '69 ln', 4, '20190307', 'man', 30000)")
    conn.commit()
    # c.close()
    # conn.close()



fill_emp()
# a = fill_inv()

# fill_part(a)

c.close()
conn.commit()
conn.close()


#
